package com.example.fichero3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView listView = findViewById(R.id.listView);

        // Cargar datos desde el archivo de recursos
        List<WebItem> webItemList = cargarDatosDesdeRecurso(R.raw.webs_favoritas);

        // Crear y configurar el adaptador
        WebAdapter adapter = new WebAdapter(this, webItemList);
        listView.setAdapter(adapter);
    }

    private List<WebItem> cargarDatosDesdeRecurso(int resourceId) {
        List<WebItem> webItemList = new ArrayList<>();

        InputStream inputStream = getResources().openRawResource(resourceId);
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

        try {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length == 4) {
                    String nombre = parts[0].trim();
                    String enlace = parts[1].trim();
                    String logo = parts[2].trim();
                    int identificador = Integer.parseInt(parts[3].trim());

                    WebItem webItem = new WebItem(nombre, enlace, logo, identificador);
                    webItemList.add(webItem);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                inputStream.close();
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return webItemList;
    }
}
