package com.example.fichero3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class WebAdapter extends ArrayAdapter<WebItem> {

    public WebAdapter(Context context, List<WebItem> webItemList) {
        super(context, 0, webItemList);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        WebItem webItem = getItem(position);

        // Check if an existing view is being reused, otherwise inflate the view
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_web, parent, false);
        }

        // Lookup view for data population
        TextView tvNombre = convertView.findViewById(R.id.tvNombre);
        TextView tvEnlace = convertView.findViewById(R.id.tvEnlace);

        // Populate the data into the template view using the data object
        tvNombre.setText(webItem.getNombre());
        tvEnlace.setText(webItem.getEnlace());

        // Return the completed view to render on screen
        return convertView;
    }
}
