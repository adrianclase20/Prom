package com.example.fichero3;
public class WebItem {
    private String nombre;
    private String enlace;
    private String logo;
    private int identificador;

    public WebItem(String nombre, String enlace, String logo, int identificador) {
        this.nombre = nombre;
        this.enlace = enlace;
        this.logo = logo;
        this.identificador = identificador;
    }

    // Getter methods
    public String getNombre() {
        return nombre;
    }

    public String getEnlace() {
        return enlace;
    }

    public String getLogo() {
        return logo;
    }

    public int getIdentificador() {
        return identificador;
    }
}
