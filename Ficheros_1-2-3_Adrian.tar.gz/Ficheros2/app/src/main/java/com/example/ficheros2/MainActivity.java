package com.example.ficheros2;

// MainActivity.java
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Obtener referencia al Spinner
        Spinner spinnerProvincias = findViewById(R.id.spinnerProvincias);

        // Cargar nombres de provincias desde el archivo de recurso
        List<String> provincias = cargarProvinciasDesdeRecurso(R.raw.provincias);

        // Crear un adaptador para el Spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, provincias);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // Configurar el adaptador en el Spinner
        spinnerProvincias.setAdapter(adapter);
    }

    private List<String> cargarProvinciasDesdeRecurso(int resourceId) {
        List<String> provincias = new ArrayList<>();
        InputStream inputStream = getResources().openRawResource(resourceId);

        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            String linea;

            while ((linea = reader.readLine()) != null) {
                provincias.add(linea);
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                inputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return provincias;
    }
}
