package com.example.ejerciciofragments;

public class Videojuego {
    private String titulo;
    private String desarrollador;
    private String sinopsis;

    public Videojuego(String titulo, String desarrollador, String sinopsis) {
        this.desarrollador = desarrollador;
        this.sinopsis = sinopsis;
        this.titulo = titulo;
    }

    public String getDesarrollador() {
        return desarrollador;
    }

    public String getSinopsis() {
        return sinopsis;
    }

    public String getTitulo() {
        return titulo;
    }
}
