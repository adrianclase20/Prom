package com.example.ejerciciofragments;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class FragmentListado extends Fragment {
    private Videojuego[] datos = new Videojuego[] {
            new Videojuego("The Legend of Zelda: Breath of the Wild", "Nintendo", "Aventura épica en el reino de Hyrule"),
            new Videojuego("Cyberpunk 2077", "CD Projekt", "Futuro distópico con elementos de rol y acción"),
            new Videojuego("Fortnite", "Epic Games", "Battle Royale con construcción y eventos en constante evolución")
    };
    private ListView lstListado;
    private VideojuegoListener listener;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_listado, container, false);
    }
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        lstListado = (ListView)getView().findViewById(R.id.lstListado);
        lstListado.setAdapter(new AdaptadorVideojuego(this));
        lstListado.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                if (listener != null)
                    listener.onVideojuegoSeleccionada(
                            (Videojuego)lstListado.getAdapter().getItem(position));
            }
        });
    }

    public interface VideojuegoListener{
        void onVideojuegoSeleccionada(Videojuego p);
    }
    public void setVideojuegoListener (VideojuegoListener listener){
        this.listener =listener;
    }

    class AdaptadorVideojuego extends ArrayAdapter<Videojuego> {
        Activity context;
        AdaptadorVideojuego(Fragment context) {
            super(context.getActivity(), R.layout.listitem_pelicula, datos);
            this.context = context.getActivity();
        }

        @NonNull
        @Override
        public View getView(int position,
                            @Nullable View convertView,
                            @NonNull ViewGroup parent) {
            LayoutInflater inflater = context.getLayoutInflater();
            View item = inflater.inflate(R.layout.listitem_pelicula, null);
            TextView lblTitulo = (TextView) item.findViewById(R.id.lblTitulo);
            lblTitulo.setText(datos[position].getTitulo());
            TextView lblDesarrollador = (TextView)item.findViewById(R.id.lblDesarrollador);
            lblDesarrollador.setText(datos[position].getDesarrollador());
            return (item);
        }
    }
}