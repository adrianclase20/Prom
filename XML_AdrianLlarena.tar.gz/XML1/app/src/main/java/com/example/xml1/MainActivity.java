package com.example.xml1;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ExecutorService executorService;
    private RecyclerView recyclerView;
    private NoticiasAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        executorService = Executors.newSingleThreadExecutor();
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        ejecutarTareaAsincrona();
    }

    private void ejecutarTareaAsincrona() {
        executorService.submit(new Runnable() {
            @Override
            public void run() {
                try {
                    RssParser parser = new RssParser();
                    List<Noticia> noticias = parser.parsearRSS("https://e00-marca.uecdn.es/rss/futbol/futbol-femenino.xml");
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            adapter = new NoticiasAdapter(noticias, MainActivity.this);
                            recyclerView.setAdapter(adapter);
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executorService.shutdown();
    }
}

