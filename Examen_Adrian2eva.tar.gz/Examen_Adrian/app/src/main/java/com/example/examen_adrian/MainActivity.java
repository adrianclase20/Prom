package com.example.examen_adrian;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void quimico(View v) {
        Intent i = new Intent(MainActivity.this, Quimico.class);
        startActivity(i);
    }
    public void consultas(View v) {
        Intent i = new Intent(MainActivity.this, SearchActivity.class);
        startActivity(i);
    }
    public void salir(View v) {
        new AlertDialog.Builder(this)
                .setTitle("Salir")
                .setMessage("¡¡¡ADIOOOOS!!!")
                .setPositiveButton("Cerrar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }

                })
                .show();
    }
}