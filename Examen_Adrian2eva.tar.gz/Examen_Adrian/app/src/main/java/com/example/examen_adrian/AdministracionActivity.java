package com.example.examen_adrian;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.database.sqlite.SQLiteDatabase;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class AdministracionActivity extends AppCompatActivity {


    private SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_administracion);
        SQLiteHelper helper = new SQLiteHelper(this, "DBExamen", null, 1);
        db = helper.getWritableDatabase();
    }

    //Caundo se pulsa el boton submit
    public void submit(View v){
        EditText edID = findViewById(R.id.edID);
        EditText edNOMBRE = findViewById(R.id.edNOMBRE);
        EditText edSIMBOLO = findViewById(R.id.edSIMBOLO);
        EditText edNUM = findViewById(R.id.edNUM);
        EditText edESTADO = findViewById(R.id.edESTADO);

        crearModificar(edID.getText().toString(), edNOMBRE.getText().toString(), edSIMBOLO.getText().toString(), edNUM.getText().toString(), edESTADO.getText().toString());


        new AlertDialog.Builder(this)
                .setTitle("Mensaje")
                .setMessage("Se ha INSERTADO con exito")
                .setPositiveButton("Cerrar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent i = new Intent(AdministracionActivity.this, AdministracionActivity.class);
                        startActivity(i);
                    }

                })
                .show();

    }

    public void deleteCourse(View v) {
        EditText edID = findViewById(R.id.edID);
        db.execSQL("DELETE FROM Elementos WHERE ID='"+edID.getText().toString()+"'");
        db.close();
        new AlertDialog.Builder(this)
                .setTitle("Mensaje")
                .setMessage("Se ha BORRADO con exito")
                .setPositiveButton("Cerrar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent i = new Intent(AdministracionActivity.this, AdministracionActivity.class);
                        startActivity(i);
                    }

                })
                .show();

    }
//    public void modificar(View v) {
//        EditText edID = findViewById(R.id.edID);
//        EditText edNOMBRE = findViewById(R.id.edNOMBRE);
//        EditText edSIMBOLO = findViewById(R.id.edSIMBOLO);
//        EditText edNUM = findViewById(R.id.edNUM);
//        EditText edESTADO = findViewById(R.id.edESTADO);
//        db.execSQL("DELETE FROM Elementos WHERE ID='"+edID.getText().toString()+"'");
//        crearModificar(edID.getText().toString(), edNOMBRE.getText().toString(), edSIMBOLO.getText().toString(), edNUM.getText().toString(), edESTADO.getText().toString());
//        db.close();
//        new AlertDialog.Builder(this)
//                .setTitle("Mensaje")
//                .setMessage("Se ha MODIFICADO con exito")
//                .setPositiveButton("Cerrar", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//
//                    }
//
//                })
//                .show();
//
//    }
    public void modificar(View v) {
        EditText edID = findViewById(R.id.edID);
        EditText edNOMBRE = findViewById(R.id.edNOMBRE);
        EditText edSIMBOLO = findViewById(R.id.edSIMBOLO);
        EditText edNUM = findViewById(R.id.edNUM);
        EditText edESTADO = findViewById(R.id.edESTADO);
        db.execSQL("DELETE FROM Elementos WHERE ID='"+edID.getText().toString()+"'");
        crearModificar(edID.getText().toString(), edNOMBRE.getText().toString(), edSIMBOLO.getText().toString(), edNUM.getText().toString(), edESTADO.getText().toString());
        db.close();
        new AlertDialog.Builder(this)
                .setTitle("Mensaje")
                .setMessage("Se ha MODIFICADO con exito")
                .setPositiveButton("Cerrar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent i = new Intent(AdministracionActivity.this, AdministracionActivity.class);
                        startActivity(i);
                    }

                })
                .show();

    }
    public void crearModificar(String id, String nombre, String simbolo, String num,String estado){


            ContentValues valores = new ContentValues();
            valores.put("id", id);
            valores.put("nombre", nombre);
            valores.put("simbolo", simbolo);
            valores.put("num", num);
            valores.put("estado", estado);
            db.insert("Elementos", null, valores);

    }

    public void volver(View v) {
        Intent i = new Intent(AdministracionActivity.this, MainActivity.class);
        startActivity(i);
    }

}