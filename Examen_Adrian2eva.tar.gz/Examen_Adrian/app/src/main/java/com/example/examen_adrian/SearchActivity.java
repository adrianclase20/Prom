package com.example.examen_adrian;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.database.sqlite.SQLiteDatabase;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class SearchActivity extends AppCompatActivity {
    private SQLiteDatabase db;
    private EditText Consulta;

    private TextView tvNum;
    private TextView tvNombre;
    private TextView tvEstado;
    private TextView tvId;
    private TextView tvSimbolo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);


        EditText consulta2 = findViewById(R.id.consulta2);


        SQLiteHelper helper = new SQLiteHelper(this, "DBExamen", null, 1);
        db = helper.getWritableDatabase();

//        mostrar(consulta2.getText().toString());

    }


    private void mostrar(String nombre) {
//        Cursor c = db.query("Elementos", new String[]{"id, nombre, simbolo, num,estado"}, "nombre=?", new String[]{nombre}, null, null, null);
//        if (c.moveToFirst()) {
//            do {
//
//                tvId.setText(tvId.getText()+"\n");
//                tvNombre.setText(tvNombre.getText()+"\n");
//                tvNum.setText(tvNum.getText()+"\n");
//                tvSimbolo.setText(tvNombre.getText()+"\n");
//                tvEstado.setText(tvEstado.getText()+"\n");
//            } while (c.moveToNext());
//        }
    }
    public void salir(View v) {
        Intent i = new Intent(SearchActivity.this, MainActivity.class);
        startActivity(i);
    }
}