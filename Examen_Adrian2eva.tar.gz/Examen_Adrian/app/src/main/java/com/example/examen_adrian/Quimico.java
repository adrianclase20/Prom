package com.example.examen_adrian;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Quimico extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quimico);
        txtNomUsuario = (EditText)findViewById(R.id.txtNomUsuario);
        txtPassword = (EditText)findViewById(R.id.txtPassword);
    }
    private Dialog_Inicio dialog_inicio;
    private Dialog_Atras dialog_atras;
    private NotificationManager notificationManager;
    static final String CANAL_ID = "canal_inicioSesion";


    private final String NOM_USER = "admin";
    private final String PASS_USER = "admin";
    private EditText txtNomUsuario;
    private EditText txtPassword;





    public void listener_butIniciar(View view)
    {
        boolean checkDatos = comprobarDatos();

        if(checkDatos)
        {


            Intent intent = new Intent(Quimico.this, AdministracionActivity.class);
            intent.putExtra("nomUser",txtNomUsuario.getText().toString());
            startActivityForResult(intent,1);
        }
        else
        {
            //Inicio de sesión no válido. Mostramos advertencia y reseteamos campos
            if(dialog_inicio == null)
                dialog_inicio = new Dialog_Inicio();
            dialog_inicio.show(getSupportFragmentManager(), "dialog_inicio");

            txtNomUsuario.setText("");
            txtPassword.setText("");
        }
    }

    private boolean comprobarDatos()
    {
        if( txtNomUsuario.getText().toString().equals(NOM_USER)
                &&  txtPassword.getText().toString().equals(PASS_USER))
            return true;
        return false;
    }






    public void onBackPressed() {
        super.onBackPressed();
        dialog_atras = new Dialog_Atras();
        dialog_atras.show(getSupportFragmentManager(), "dialog_atras");
    }

    //Botón positivo pulsado
    public void onPossitiveButtonClick()
    {
        finish();
        System.exit(0);
    }
    public void cancelar(View v) {
        Intent i = new Intent(Quimico.this, MainActivity.class);
        startActivity(i);
    }

}