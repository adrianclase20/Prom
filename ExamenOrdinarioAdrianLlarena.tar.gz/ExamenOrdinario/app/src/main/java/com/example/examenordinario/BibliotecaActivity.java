package com.example.examenordinario;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class BibliotecaActivity extends AppCompatActivity {
    private Button botonNuevo,botonListado,botonBuscar,volver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_biblioteca);
        //ids

        botonNuevo = findViewById(R.id.botonNuevo);
        botonBuscar = findViewById(R.id.botonBuscar);
        botonListado = findViewById(R.id.botonListado);
        volver = findViewById(R.id.volver);

        // Conexion con base de datos
        BibliotecaSQLiteHelper bibliodbh =
                new BibliotecaSQLiteHelper(this, "DBBiblio", null, 1);
        BibliotecaDAO bibDao = new BibliotecaDAO();
        if(bibDao.cuantosLibros(bibliodbh)==0){
            // no hay libros dados de alta
            botonListado.setEnabled(false);
        }
        else{
            botonListado.setEnabled(true);
        }
        botonBuscar.setEnabled(false);
        botonNuevo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(BibliotecaActivity.this, NuevoLibro.class);
                startActivity(i);
            }
        });
        botonListado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(BibliotecaActivity.this, ListadoLibros.class);
                startActivity(i);
            }
        });
        volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

}