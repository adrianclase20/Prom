package com.example.examenordinario;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class BibliotecaSQLiteHelper extends SQLiteOpenHelper {
    private static final String SQL_INSERT_LIBROS =
            "INSERT INTO Libro (isbn, titulo, autor, editorial) " +
                    "VALUES ('9788491641780', 'Memoria del Consumismo', 'Federico Jimenez Losantos', 'La Esfera de los libros'), " +
                    "('9788423350995', 'El guardian invisible', 'Dolores Redondo', 'Destino'), " +
                    "('9788408163435', 'La sobra del viento', 'Carlos Ruiz Zafon', 'Planeta')";
    public BibliotecaSQLiteHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);

    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Creacion de la tabla de libros
        db.execSQL(
                "CREATE TABLE Libro (" +
                        "isbn String PRIMARY KEY," +
                        "titulo TEXT," +
                        "autor TEXT," +
                        "editorial TEXT)");
        db.execSQL(
                "INSERT INTO Libro (isbn, titulo, autor, editorial) " +
                        "VALUES ('9788491641780', 'Memoria del Consumismo', 'Federico Jimenez Losantos', 'La Esfera de los libros')");
        db.execSQL(
                "INSERT INTO Libro (isbn, titulo, autor, editorial) " +
                        "VALUES ('9788423350995', 'El guardian invisible', 'Dolores Redondo', 'Destino')");
        db.execSQL(
                "INSERT INTO Libro (isbn, titulo, autor, editorial) " +
                        "VALUES ('9788408163435', 'La sobra del viento', 'Carlos Ruiz Zafon', 'Planeta')");
        /*+
                        "('9788423350995', 'El guardian invisible', 'Dolores Redondo', 'Destino'), " +
                        "('9788408163435', 'La sobra del viento', 'Carlos Ruiz Zafon', 'Planeta')");
*/
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS Libro");
        db.execSQL("CREATE TABLE Libro (" +
                "isbn String PRIMARY KEY," +
                "titulo TEXT," +
                "autor TEXT," +
                "editorial TEXT)");
    }

}
