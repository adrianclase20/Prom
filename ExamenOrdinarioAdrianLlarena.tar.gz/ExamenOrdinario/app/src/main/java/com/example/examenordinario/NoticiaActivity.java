package com.example.examenordinario;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.io.InputStream;

public class NoticiaActivity extends AppCompatActivity {
    private Spinner spinnerLocalidades;

    private ExecutorService executorService;
    private RecyclerView recyclerView;
    private NoticiaAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_noticia);

        executorService = Executors.newSingleThreadExecutor();
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        spinnerLocalidades = findViewById(R.id.spinnerLocalidades);
        ArrayList<String[]> array = leerFichero();
        cargarSpinner(array);



        spinnerLocalidades.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            String urlAndalucia="https://ep00.epimg.net/rss/ccaa/andalucia.xml";
            String urlCataluna="https://feeds.elpais.com/mrss-s/pages/ep/site/elpais.com/section/espana/subsection/catalunya";
            String urlComunidadV="https://ep00.epimg.net/rss/ccaa/valencia.xml";
            String urlMadrid="https://feeds.elpais.com/mrss-s/pages/ep/site/elpais.com/section/espana/subsection/madrid";
            String urlVasco="https://ep00.epimg.net/rss/ccaa/paisvasco.xml";
            String urlGalicia="https://ep00.epimg.net/rss/ccaa/galicia.xml";

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                //se que esto tendria que cogerlo de el txt pero no me salia
                if (i==0){
                    ejecutarTareaAsincrona(urlAndalucia);
                }
                if (i==1){
                    ejecutarTareaAsincrona(urlCataluna);
                }
                if (i==2){
                    ejecutarTareaAsincrona(urlComunidadV);
                }
                if (i==3){
                    ejecutarTareaAsincrona(urlMadrid);
                }
                if (i==4){
                    ejecutarTareaAsincrona(urlVasco);
                }
                if (i==5){
                    ejecutarTareaAsincrona(urlGalicia);
                }



            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

    }

    private void ejecutarTareaAsincrona(String url) {
        executorService.submit(new Runnable() {
            @Override
            public void run() {
                try {
                    RssParser parser = new RssParser();
                    List<Noticia> noticias = parser.parsearRSS(url);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            adapter = new NoticiaAdapter(noticias, NoticiaActivity.this);
                            recyclerView.setAdapter(adapter);
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    public void volver(View v) {
        Intent i = new Intent(NoticiaActivity.this, MainActivity.class);
        startActivity(i);
    }
    private void cargarSpinner(ArrayList<String[]> array) {
        ArrayList<String> lista = new ArrayList<>();

        for(int i = 0;i<array.size();i++){
            lista.add(array.get(i)[0]); // la primera posicion es la localidad
        }
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, lista);
        spinnerLocalidades.setAdapter(arrayAdapter);
    }
    public ArrayList<String[]> leerFichero(){
        String[] partes;
        ArrayList<String[]> array = new ArrayList<String[]>();
        try {
            InputStream fraw = getResources().openRawResource(R.raw.url_noticas_comunidades);
            BufferedReader brin = new BufferedReader( new InputStreamReader(fraw));
            String linea= brin.readLine();
            partes = linea.split(";");
            array.add(partes);
            while (linea!=null){
                Log.i("Ficheros", linea);
                linea=brin.readLine();
                partes = linea.split(";");
                array.add(partes);
            }
            fraw.close();
        }
        catch (Exception ex) {
            Log.e ("Ficheros", "Error al leer fichero desde recurso raw");
        }

        return array;
    }
}


