package com.example.examenordinario;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class NuevoLibro extends AppCompatActivity {
    private Button insertar,cancelar,volver;
    private EditText titulo,autor,isbn,editorial;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nuevo_libro);

        //ids
        insertar = findViewById(R.id.botonInsertar);
        cancelar = findViewById(R.id.botonCancelar);
        volver = findViewById(R.id.volverInsert);

        titulo = findViewById(R.id.titulo);
        autor = findViewById(R.id.autor);
        isbn = findViewById(R.id.isbn);
        editorial = findViewById(R.id.editorial);


        BibliotecaSQLiteHelper bibliodbh =
                new BibliotecaSQLiteHelper(this, "DBBiblio", null, 1);

        volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                vaciar();
            }
        });
        insertar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!algunoVacio()){

                        BibliotecaDAO bibdao = new BibliotecaDAO();
                        bibdao.nuevoLibro(bibliodbh, isbn.getText().toString(), titulo.getText().toString(), autor.getText().toString(), editorial.getText().toString());
                        vaciar();
                        Toast.makeText(NuevoLibro.this, "Libro añadido!", Toast.LENGTH_SHORT).show();

                }
                else{
                    Toast.makeText(NuevoLibro.this, "Por favor rellena todos los campos", Toast.LENGTH_SHORT).show();


                }
            }
        });
    }

    private void vaciar() {
        titulo.setText("");
        autor.setText("");
        isbn.setText("");
        editorial.setText("");
    }

    private boolean algunoVacio(){
        if(titulo.getText().toString().trim().equals(""))
            return true;
        if(isbn.getText().toString().trim().equals(""))
            return true;
        if(autor.getText().toString().trim().equals(""))
            return true;
        if(editorial.getText().toString().trim().equals(""))
            return true;
        return false;
    }
}